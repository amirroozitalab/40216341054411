#include <iostream>
using namespace std;

int main()
{
    int i;
    i = 5;
    do
    {
        i *= (3 + 2);
        cout << "future ";
    } while (i < 76);
    return 0;
}