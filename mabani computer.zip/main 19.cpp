#include <iostream>
using namespace std;

int main()
{
    int i;
    i = 5;
    do
        cout << "further";
    while (i > 76);
    return 0;
}