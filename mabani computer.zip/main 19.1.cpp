#include <iostream>
using namespace std;

int main()
{
    int for2;
    for2 = 1;
    while (for2++ < 3)
        cout << "seed\n";
    return 0;
}